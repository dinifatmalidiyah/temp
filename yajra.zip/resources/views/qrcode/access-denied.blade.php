<!-- resources/views/access-denied.blade.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Akses Ditolak</title>
</head>

<body>
    <h1>Akses Ditolak</h1>
    <p>Anda tidak memiliki izin untuk mengakses halaman ini.</p>
</body>

</html>