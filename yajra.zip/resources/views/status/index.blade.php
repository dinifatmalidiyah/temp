@extends('layout.main')
@section('title'){{'status'}} @endsection
@section('content')
@endsection